﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ToursApp1._0
{
    internal class Maneger
    {
        public static Frame MainFrame { get; set; }
    }
}
